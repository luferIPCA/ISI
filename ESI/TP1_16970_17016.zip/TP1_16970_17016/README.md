# TP1_16970_17016
## <author1> Bruno Lopes 16970</author1>
## <author2> Ines Alves 17016 </author2>
### <email1> a16970@alunos.ipca.pt </email1>
### <email2> a17016@alunos.ipca.pt </email2>

O projeto desenvolvido em Ketlle, para poder ser executado com sucesso, deverão ser alteradas as diretorias.

O projeto em C# realiza a leitura dos filmes numa pasta "D:\Temp\Movies\" para alterar a localização de leitura apenas é necessário alterar a variável FolderPath para o caminho desejado.